@extends('layout.admin_and_user_page.master')
@section('main')
    <div class="row">
        <div class="col-md-12">
            {{ Breadcrumbs::render('admin.index') }}
        </div>
    </div>
    <h2>chào mừng bạn đến với trang quản lý</h2>
@endsection
