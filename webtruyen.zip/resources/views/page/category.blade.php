@extends('layout.front_page.master')
@section('main')

@endsection
