@extends('layout.front_page.master')
@section('main')
    <section class="Breadcrumbs">
        <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Photos</a></li>
            <li class="breadcrumb-item"><a href="#">Summer 2017</a></li>
            <li class="breadcrumb-item"><a href="#">Italy</a></li>
            <li class="breadcrumb-item active">Rome</li>
          </ul>
    </section>
    <section class="banner">
        <div class="banner__item banner__left__top">
            <img src="https://i.truyenvua.xyz/slider/290x191/slider_1559213484.jpg?gf=hdfgdfg&mobile=2" alt="">
        </div>
        <div class="banner__item banner__left__bottom">
            <img src="https://i.truyenvua.xyz/slider/290x191/slider_1560493497.jpg?gf=hdfgdfg&mobile=2" alt="">
        </div>
        <div class="banner__item banner__right__top">
            <img src="https://i.truyenvua.xyz/slider/290x191/slider_1567830171.jpg?gf=hdfgdfg&mobile=2" alt="">
        </div>
        <div class="banner__item banner__right__bottom">
            <img src="https://i.truyenvua.xyz/slider/290x191/slider_1561609693.jpg?gf=hdfgdfg&mobile=2" alt="">
        </div>
        <div class="banner__item banner__center">
            <img src="https://i.truyenvua.xyz/slider/583x386/slider_1560573084.jpg?gf=hdfgdfg&mobile=2" alt="">
        </div>
    </section>
    <div class="fb-comments" data-href="https://webtruyen.com"
         data-width="100%" data-numposts="10" data-lazy="true" data-colorscheme="dark"
    ></div>
@endsection
