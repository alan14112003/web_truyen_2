<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/star-rating-svg.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/story.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-7">
            <?php echo e(Breadcrumbs::render("show_story", $story)); ?>

        </div>
    </div>
    <div class="story_info">
        <div class="story_title">
            <h3>Thông tin truyện</h3>
        </div>
        <div class="story_name">
            <h2><?php echo e($story->name); ?></h2>
        </div>
        <div class="story_box">
            <div class="story_box_left">
                <div class="story_box_left_top">
                    <a href="<?php echo e($story->image_url); ?>" target="_blank">
                        <div class="story_box_left_top_image">
                            <img src="<?php echo e($story->image_url); ?>" alt="<?php echo e($story->name); ?>">
                            <div class="book-shadow"></div>
                        </div>
                    </a>
                </div>
                <div class="story_box_left_bottom">
                    <div class="story_box_left_bottom_item">
                        <strong>Phân loại:</strong>
                        <span><?php echo e($story->level_name); ?></span>
                    </div>
                    <div class="story_box_left_bottom_item">
                        <strong>Tác giả:</strong>
                        <a href="<?php echo e(route('advanced_search')); ?>?author=<?php echo e($story->author->id); ?>"><?php echo e($story->author->name); ?></a>
                    </div>
                    <div class="story_box_left_bottom_item">
                        <strong>Thể loại:</strong>
                        <span><?php echo $story->categories_link; ?></span>
                    </div>
                    <div class="story_box_left_bottom_item">
                        <strong>Tình trạng:</strong>
                        <span><?php echo e($story->status_name); ?></span>
                    </div>
                    <div class="story_box_left_bottom_item">
                        <strong>Số chương:</strong>
                        <span><?php echo e($story->chapter->count()); ?></span>
                    </div>
                </div>
            </div>
            <div class="story_box_right">
                <div class="story_box_right_rate">
                    <div class="rate_box" data-rating="<?php echo e($starAvg); ?>"></div>
                    <div class="rate_desc">
                        Đánh giá: <span><?php echo e($starAvg); ?></span>/5 từ <span><?php echo e($starPerson); ?></span> lượt
                    </div>
                </div>
                <div class="story_box_right_desc">
                    <?php echo $story->descriptions; ?>

                </div>
            </div>
        </div>
    </div>
    <div class="chapter_box">
        <div class="story_title chapter_title">
            <h3>Danh sách chương</h3>
            <form action="" method="get" class="form-inline" id="formFilter">
                <label class="control-label" style="text-transform: lowercase; margin-right: 8px;" for="selectFilter">Sắp xếp theo</label>
                <select class="form-control" style="height: auto; background: transparent" name="sort" id="selectFilter">
                    <option <?php if($sort === 'asc'): ?> selected <?php endif; ?> value="asc">cũ nhất</option>
                    <option <?php if($sort === 'desc'): ?> selected <?php endif; ?> value="desc">mới nhất</option>
                </select>
            </form>
        </div>
        <div class="chapter_list">
            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="chapter_list_item">
                    <a href="<?php echo e(route('show_chapter', [$story->slug, $chapter->number])); ?>">
                        <span class="chapter_box_item_text">
                            <span>Chương </span> <?php echo e($chapter->number); ?>: <?php echo e($chapter->name); ?>

                        </span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="comments_box">
        <div class="fb-comments" data-href="<?php echo e(route('show_story', $story->slug)); ?>"
             data-width="100%" data-numposts="10" data-colorscheme="dark"></div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="<?php echo e(asset('front_asset/js/jquery.star-rating-svg.js')); ?>"></script>
        <script>
            const formFilter = document.getElementById('formFilter')
            const selectFilter = document.getElementById('selectFilter')
            selectFilter.onchange = () => {
                formFilter.submit();
            }
        </script>
        <script type="text/javascript">
            $(document).ready(function()
            {
                const rateBox = $('.rate_box')
                rateBox.starRating({
                    starSize: 20,
                    useFullStars: true,
                    starShape: 'rounded',
                    ratedColor: '#FE7 !important',
                    callback: function(currentRating){
                        submitRate(currentRating)
                    },
                })

                // khi thực hiện kích vào nút Sign in
                function submitRate(star)
                {
                    let data = {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        "star": star,
                    }
                    //Sử dụng hàm $.ajax()
                    $.ajax({
                        type : 'POST', //kiểu post
                        url  : '<?php echo e(route('star.create', $story->id)); ?>', //gửi dữ liệu sang trang submit.php
                        data : data,
                        success :  function(data)
                        {
                            if($.isEmptyObject(data.error)){
                                alert(data.success);
                            }else{
                                alert(data.error);
                            }
                        }
                    });
                    return false;
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/page/story.blade.php ENDPATH**/ ?>