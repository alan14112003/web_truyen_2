<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            [class^="pe-"] {
                font-size: 30px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->level_id === 2 || auth()->user()->level_id === 3): ?>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e(Breadcrumbs::render('admin.categories.index')); ?>

                </div>
            </div>
        <?php endif; ?>
        <?php if(auth()->user()->level_id === 1): ?>
            <div class="row">
                <div class="col-md-12">
                    <?php echo e(Breadcrumbs::render('user.categories.index')); ?>

                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="row">
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->level_id === 2 || auth()->user()->level_id === 3): ?>
                <a href="<?php echo e(route("admin.$table.create")); ?>" class="pe-7s-plus"
                   style="font-size: 40px; margin: 24px;"></a>
            <?php endif; ?>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                </div>
                <div class="card-body">
                    <div class="bootstrap-table">
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tên</th>
                                    <th>Mô tả</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->descriptions); ?></td>
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php if(auth()->user()->level_id === 2 || auth()->user()->level_id === 3): ?>
                                                <td>
                                                    <div style="display: flex;">
                                                        <a href="<?php echo e(route("admin.$table.edit", $category->id)); ?>"
                                                           class="pe-7s-note">
                                                        </a>
                                                        <form action="<?php echo e(route("admin.$table.destroy", $category->id)); ?>"
                                                              method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>
                                                            <button class="pe-7s-trash text-danger"
                                                                    style="border: none; background: transparent"></button>
                                                        </form>
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="fixed-table-pagination">
                            <div class="pull-right pagination">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/user/categories/index.blade.php ENDPATH**/ ?>