<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .card {
                max-width: 400px;
                margin: auto;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.categories.create')); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 style="padding: 24px 24px 0;"><?php echo e($title ?? ''); ?></h3>
                    <hr>
                </div>
                <div class="content">
                    <form action="<?php echo e(route("admin.$table.store")); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name" class="control-label">Tên</label>
                            <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>">
                            <?php if($errors->any()): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="describe" class="control-label">Mô tả</label>
                            <textarea class="form-control" rows="4" name="descriptions" id="describe">
                            <?php echo e(old('descriptions')); ?>

                            </textarea>
                            <?php if($errors->any()): ?>
                                <span class="text-danger"><?php echo e($errors->first('descriptions')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="footer text-center">
                            <button class="btn btn-primary">Thêm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>