<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .story_name h2 {
                font-size: 2.4rem;
                margin: 0 0 5px;
                line-height: 35px;
                text-transform: uppercase;
                font-family: "Roboto Condensed", Tahoma, sans-serif;
                text-align: center;
            }
            .button_edit {
                position: fixed;
                right: 5rem;
                top: 15rem;
                z-index: 1000;
            }

            .button_edit i {
                font-size: 3rem;
            }
            .chapter_name {
                font-size: 1.6rem;
                margin: 0 0 5px;
                line-height: 35px;
                text-align: center;
            }

            hr.chapter-start {
                background: url(//static.8cache.com/img/spriteimg_new_white_op.png) -200px -27px no-repeat;
                width: 59px;
                height: 20px;
            }

            hr.chapter-end {
                background: url(//static.8cache.com/img/spriteimg_new_white_op.png) 0 -51px no-repeat;
                width: 277px;
                height: 35px;
            }

            .button_box {
                margin: 24px auto;
                width: fit-content;
                display: flex;
                flex-wrap: wrap;
            }

            .dropdown,
            .dropup {
                margin: 0 8px;
            }

            .content {
                max-width: 1000px;
                margin: auto;
            }

            .content p {
                text-align: justify;
                font-size: 2.2rem;
            }

            @media screen and (max-width: 63.9375em) {
                .button_box .btn-wd {
                    min-width: fit-content;
                    padding: 8px 8px;
                }
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="button_box button_edit">
        <?php if($chapter->pin === \App\Enums\ChapterPinEnum::UPLOADING): ?>
            <form action="<?php echo e(route("admin.stories.chapters.approve", [$story->id, $chapter->number])); ?>"
                  method="post">
                <?php echo csrf_field(); ?>
                <button rel="tooltip" data-original-title="duyệt"
                        class="btn btn-simple btn-success btn-icon
                                                                    table-action">
                    <i class="fa fa-check"></i>
                </button>
            </form>
        <?php endif; ?>
        <form action="<?php echo e(route("admin.stories.chapters.un_approve", [$story->id, $chapter->number])); ?>"
              method="post">
            <?php echo csrf_field(); ?>
            <button rel="tooltip" data-original-title="không duyệt"
                    class="btn btn-simple btn-warning btn-icon
                                                                    table-action">
                <i class="fa fa-ban"></i>
            </button>
        </form>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.chapters.show', $story, $chapter)); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="story_name">
                <h2 class="text-info"><?php echo e($story->name); ?></h2>
            </div>
            <div class="chapter_name">
                <span>Chương </span> <?php echo e($chapter->number); ?>: <?php echo e($chapter->name); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <hr class="chapter-start">
            <div class="button_box">
                <a href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $pre])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === $first): ?> disabled <?php endif; ?>">
                    Chương trước</a>
                <div class="dropdown">
                    <button class="btn btn-info btn-fill dropdown-toggle" type="button" data-toggle="dropdown">Chọn
                        chương
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $chapterList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php if($chapterItem === $chapter->number): ?> class="active disabled" <?php endif; ?>><a
                                        href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $chapterItem])); ?>">Chương
                                    <?php echo e($chapterItem); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <a href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $next])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === $last): ?> disabled <?php endif; ?>">Chương
                    sau
                </a>
            </div>
            <hr class="chapter-end">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="content">
                <?php echo $chapter->content; ?>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <hr class="chapter-end">
            <div class="button_box">
                <a href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $pre])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === $first): ?> disabled <?php endif; ?>">
                    Chương trước</a>
                <div class="dropup">
                    <button class="btn btn-info btn-fill dropdown-toggle" type="button" data-toggle="dropdown">Chọn
                        chương
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $chapterList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php if($chapterItem === $chapter->number): ?> class="active disabled" <?php endif; ?>><a
                                        href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $chapterItem])); ?>">Chương
                                    <?php echo e($chapterItem); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <a href="<?php echo e(route("admin.stories.$table.show", ['id' => $story->id, 'number' => $next])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === $last): ?> disabled <?php endif; ?>">Chương
                    sau
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/chapters/show.blade.php ENDPATH**/ ?>