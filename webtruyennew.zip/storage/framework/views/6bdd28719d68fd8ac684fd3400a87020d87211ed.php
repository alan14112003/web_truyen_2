<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            [class^="pe-"] {
                font-size: 30px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.stories.index')); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="content">
                        <form action="" method="get" id="form-filter" class="form-inline">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-target="#collapseOne" href="#" data-toggle="collapse-hover">
                                                    <div class="form-group">
                                                        <label for="">Thể loại</label>
                                                    </div>
                                                    <b class="caret"></b>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapseOne" class="panel-collapse collapse collapse-hover"
                                            style="height: 0px;">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-sm-3">
                                                        <div class="checkbox">
                                                            <input class="categories_reset" id="categories_reset"
                                                                name="" type="checkbox" value="">
                                                            <label for="categories_reset" style="padding-left: 24px">
                                                                Bỏ chọn
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-sm-3">
                                                            <div class="checkbox">
                                                                <input class="filter-input"
                                                                    <?php if(isset($categoriesFilter) && in_array($category->id, $categoriesFilter)): ?> checked <?php endif; ?>
                                                                    id="categories<?php echo e($category->id); ?>" name="categories[]"
                                                                    type="checkbox" value="<?php echo e($category->id); ?>">
                                                                <label for="categories<?php echo e($category->id); ?>"
                                                                    style="padding-left: 24px">
                                                                    <?php echo e($category->name); ?>

                                                                </label>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1 col-md-offset-3">
                                    <a href="<?php echo e(route("admin.$table.index")); ?>" class="btn btn-default btn-fill"
                                        style="margin: 24px">
                                        <i class="fa fa-spin fa-refresh"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="status" class="control-label">Tình trạng</label>
                                <select name="status" id="status" class="form-control filter-input"
                                    style="margin-left: 6px">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>"
                                            <?php if($statusFilter === (string) $value): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group" style="margin-left: 16px">
                                <label for="level" class="control-label">Phân loại</label>
                                <select name="level" id="level" class="form-control filter-input"
                                    style="margin-left: 6px">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>"
                                            <?php if($levelFilter === (string) $value): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group" style="margin-left: 16px">
                                <label for="pin" class="control-label">Trạng thái</label>
                                <select name="pin" id="pin" class="form-control filter-input"
                                    style="margin-left: 6px">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $pin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>"
                                            <?php if($pinFilter === (string) $value): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group" style="margin-left: 16px">
                                <label for="users" class="control-label">Người đăng</label>
                                <select name="users" id="users" class="form-control filter-input"
                                    style="margin-left: 6px">
                                    <option value="">All</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"
                                            <?php if($usersFilter === (string) $user->id): ?> selected <?php endif; ?>><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <div class="bootstrap-table">
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tên truyện</th>
                                        <th>Thể loại</th>
                                        <th>Số chương</th>
                                        <th>Tình trạng</th>
                                        <th>Phân loại</th>
                                        <th>Tác giả</th>
                                        <th>Người đăng</th>
                                        <th>Ảnh bìa</th>
                                        <th>Trạng thái</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($story->id); ?></td>
                                            <td><?php echo e($story->name); ?></td>
                                            <td><?php echo e($story->categories_name); ?></td>

                                            <td><?php echo e($story->chapter->count()); ?></td>
                                            <td><?php echo e($story->status_name); ?></td>
                                            <td><?php echo e($story->level_name); ?></td>
                                            <td><?php echo e($story->author->name); ?></td>
                                            <td><?php echo e(optional($story->user)->name); ?></td>
                                            <td>
                                                <a href="<?php echo e($story->image_url); ?>" target="_blank">
                                                    <img src="<?php echo e($story->image_url); ?>"
                                                        style="max-width: 100px; max-height: 150px; object-fit: cover;">
                                                </a>
                                            </td>
                                            <td><?php echo e($story->pin_name); ?></td>
                                            <td class="td-actions text-right">
                                                <div style="display: flex;">
                                                    <a rel="tooltip" data-original-title="Xem"
                                                        href="<?php echo e(route("admin.$table.view", $story->id)); ?>"
                                                        class="btn btn-simple btn-info btn-icon table-action">
                                                        <i class="fa fa-eye"></i>
                                                    </a>
                                                    <?php if($story->pin === \App\Enums\StoryPinEnum::UPLOADING): ?>
                                                        <form action="<?php echo e(route("admin.$table.approve", $story->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <button rel="tooltip" data-original-title="duyệt"
                                                                class="btn btn-simple btn-success btn-icon
                                                                    table-action">
                                                                <i class="fa fa-check"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                    <form action="<?php echo e(route("admin.$table.un_approve", $story->id)); ?>"
                                                          method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <button rel="tooltip" data-original-title="không duyệt"
                                                                class="btn btn-simple btn-warning btn-icon
                                                                    table-action">
                                                            <i class="fa fa-ban"></i>
                                                        </button>
                                                    </form>
                                                    <form action='<?php echo e(route("admin.$table.pinned", $story->id)); ?>'
                                                        method="post" id="pinnedForm">
                                                        <?php echo csrf_field(); ?>
                                                        <button style="background: transparent; border: none;">
                                                            <div class="checkbox" style="margin-top: 8px;">
                                                                <input type="checkbox" id="pin-<?php echo e($story->id); ?>"
                                                                    <?php echo e($story->pin === \App\Enums\StoryPinEnum::PINNED ? 'checked' : ''); ?>

                                                                    class="pinnedInput">
                                                                <label data-original-title="ghim" rel="tooltip"
                                                                    for="pin-<?php echo e($story->id); ?>"></label>
                                                            </div>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="fixed-table-pagination">
                            <div class="pull-right pagination">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            const formFilter = document.querySelector('#form-filter');
            const inputFilter = document.querySelectorAll('.filter-input');
            inputFilter.forEach((input) => {
                input.onchange = () => {
                    formFilter.submit();
                }
            })
            const categoriesReset = document.getElementById('categories_reset');
            categoriesReset.oninput = () => {
                inputFilter.forEach((input) => {
                    input.checked = false;
                })
                formFilter.submit();
            }
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/stories/index.blade.php ENDPATH**/ ?>