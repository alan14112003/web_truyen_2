<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .button_edit {
                position: fixed;
                right: 5rem;
                top: 15rem;
                z-index: 1000;
            }

            .button_edit a i {
                font-size: 3rem;
            }
            .button_edit button {
                margin-left: 12px;
            }

            .story_name h2 {
                font-size: 2.4rem;
                margin: 0 0 5px;
                line-height: 35px;
                text-transform: uppercase;
                font-family: "Roboto Condensed", Tahoma, sans-serif;
                text-align: center;
            }

            .chapter_name {
                font-size: 1.6rem;
                margin: 0 0 5px;
                line-height: 35px;
                text-align: center;
            }

            hr.chapter-start {
                background: url(//static.8cache.com/img/spriteimg_new_white_op.png) -200px -27px no-repeat;
                width: 59px;
                height: 20px;
            }

            hr.chapter-end {
                background: url(//static.8cache.com/img/spriteimg_new_white_op.png) 0 -51px no-repeat;
                width: 277px;
                height: 35px;
            }

            .button_box {
                margin: 24px auto;
                width: fit-content;
                display: flex;
                flex-wrap: wrap;
            }

            .dropdown,
            .dropup {
                margin: 0 8px;
            }

            .content {
                max-width: 1000px;
                margin: auto;
            }

            .content p {
                text-align: justify;
                font-size: 2.2rem;
            }

            @media screen and (max-width: 63.9375em) {
                .button_box .btn-wd {
                    min-width: fit-content;
                    padding: 8px 8px;
                }
                .button_edit {
                    flex-direction: row-reverse;
                    right: 8px;
                    top: 14rem;
                }
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="button_box button_edit">
        <a rel="tooltip" class="btn btn-simple btn-warning btn-icon edit"
           href="<?php echo e(route("user.stories.$table.edit", [$story->slug, $chapter->id])); ?>"
           data-original-title="Thay đổi thông tin chương">
            <i class="fa fa-edit"></i>
        </a>
        <form
            action='<?php echo e(route("user.stories.chapters.upload", ['slug' => $story->slug, 'id' => $chapter->id])); ?>'
            method="post" >
            <?php echo csrf_field(); ?>
            <button style="background: transparent; border: none;">
                <div class="checkbox" style="margin-top: 8px;">
                    <input type="checkbox" id="pin-<?php echo e($story->id); ?>"
                           <?php if($chapter->pin > \App\Enums\ChapterPinEnum::EDITING): ?>
                               checked
                        <?php endif; ?>
                    >
                    <label data-original-title="Đăng lên" rel="tooltip"
                           for="pin-<?php echo e($story->id); ?>"></label>
                </div>
            </button>
        </form>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('user.chapter.show', $story, $chapter)); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="story_name">
                <h2 class="text-info"><?php echo e($story->name); ?></h2>
            </div>
            <div class="chapter_name">
                <span>Chương </span> <?php echo e($chapter->number); ?>: <?php echo e($chapter->name); ?>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <hr class="chapter-start">
            <div class="button_box">
                <a href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapter->number - 1])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === 1): ?> disabled <?php endif; ?>">
                    Chương trước</a>
                <div class="dropdown">
                    <button class="btn btn-info btn-fill dropdown-toggle" type="button" data-toggle="dropdown">Chọn
                        chương
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $chapterList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php if($chapterItem === $chapter->number): ?> class="active disabled" <?php endif; ?>><a
                                        href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapterItem])); ?>">Chương
                                    <?php echo e($chapterItem); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <a href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapter->number + 1])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === count($chapterList)): ?> disabled <?php endif; ?>">Chương
                    sau
                </a>
            </div>
            <hr class="chapter-end">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="content">
                <?php echo $chapter->content; ?>

            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <hr class="chapter-end">
            <div class="button_box">
                <a href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapter->number - 1])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === 1): ?> disabled <?php endif; ?>">
                    Chương trước</a>
                <div class="dropup">
                    <button class="btn btn-info btn-fill dropdown-toggle" type="button" data-toggle="dropdown">Chọn
                        chương
                        <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $chapterList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapterItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li <?php if($chapterItem === $chapter->number): ?> class="active disabled" <?php endif; ?>><a
                                        href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapterItem])); ?>">Chương
                                    <?php echo e($chapterItem); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <a href="<?php echo e(route("user.stories.$table.show", ['slug' => $story->slug, 'number' => $chapter->number + 1])); ?>"
                   class="btn btn-info btn-fill btn-wd <?php if($chapter->number === count($chapterList)): ?> disabled <?php endif; ?>">Chương
                    sau
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/user/chapters/show.blade.php ENDPATH**/ ?>