<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.index')); ?>

        </div>
    </div>
    <h2>chào mừng bạn đến với trang quản lý</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/index.blade.php ENDPATH**/ ?>
