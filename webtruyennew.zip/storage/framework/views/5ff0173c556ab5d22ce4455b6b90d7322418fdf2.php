<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/own/index.css')); ?>">
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render("show_rank")); ?>

        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-sm-3 col-6">
                <?php if (isset($component)) { $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1 = $component; } ?>
<?php $component = App\View\Components\Story::resolve(['story' => $story] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('story'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Story::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1)): ?>
<?php $component = $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1; ?>
<?php unset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/page/show_rank.blade.php ENDPATH**/ ?>