<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/own/index.css')); ?>">
        <style>
            body.dark #form-filter {
                color: var(--color-dark);
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render("advanced_search")); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form action="" method="get" id="form-filter">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center my-4">Tìm truyện nâng cao</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-1 form-group">
                                <label class="control-label">Thể loại</label>
                            </div>
                            <div class="col-md-11">
                                <div class="row">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-2 col-6">
                                            <div class="custom-control custom-checkbox">
                                                <input
                                                       <?php if(isset($categoriesFilter) && in_array($category->id, $categoriesFilter)): ?> checked <?php endif; ?>
                                                       id="categories<?php echo e($category->id); ?>" name="categories[]"
                                                       type="checkbox" value="<?php echo e($category->id); ?>"
                                                       class="custom-control-input"
                                                >
                                                <label for="categories<?php echo e($category->id); ?>"
                                                        class="custom-control-label"
                                                >
                                                    <?php echo e($category->name); ?>

                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4" >
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="status" class="control-label">Tình trạng</label>
                            <select name="status" id="status" class="form-control filter-input"
                                    style="margin-left: 6px">
                                <option value="All">Tất cả</option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>"
                                            <?php if($statusFilter === (string) $value): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="level" class="control-label">Phân loại</label>
                            <select name="level" id="level" class="form-control filter-input"
                                    style="margin-left: 6px">
                                <option value="All">Tất cả</option>
                                <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value); ?>"
                                            <?php if($levelFilter === (string) $value): ?> selected <?php endif; ?>><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="author" class="control-label">Tác giả</label>
                            <select name="author" id="author" class="form-control filter-input"
                                    style="margin-left: 6px">
                                <option value="All">Tất cả</option>
                                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($author->id); ?>"
                                            <?php if($authorFilter === (string) $author->id): ?> selected <?php endif; ?>><?php echo e($author->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="text-center">
                    <a href="<?php echo e(route("advanced_search")); ?>" class="btn btn-sm btn-primary"
                       style="margin: 24px">
                        Bỏ chọn
                    </a>
                    <button class="btn btn-sm btn-success">Tìm kiếm</button>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-sm-3 col-6">
                <?php if (isset($component)) { $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1 = $component; } ?>
<?php $component = App\View\Components\Story::resolve(['story' => $story] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('story'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Story::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1)): ?>
<?php $component = $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1; ?>
<?php unset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1); ?>
<?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/page/advanced_search.blade.php ENDPATH**/ ?>