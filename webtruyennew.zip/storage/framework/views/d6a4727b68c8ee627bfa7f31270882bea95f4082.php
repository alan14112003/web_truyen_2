<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8"/>
    <link rel="icon" href="<?php echo e(asset('/img/page/icon.png')); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <title><?php echo e(env('APP_NAME') ?? ''); ?> - <?php echo e($title ?? 'Quản lý'); ?></title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('admin_asset/css/bootstrap.min.css')); ?>" rel="stylesheet"/>

    <!--  Light Bootstrap Dashboard core CSS    -->
    <link href="<?php echo e(asset('admin_asset/css/light-bootstrap-dashboard.css? v=1.4.1')); ?>" rel="stylesheet"/>

    <!--  css for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('admin_asset/css/demo.css')); ?>" rel="stylesheet"/>


    <!--     Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('admin_asset/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet"/>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>

<div class="wrapper">
    <?php echo $__env->make('layout.admin_and_user_page.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">

        <?php echo $__env->make('layout.admin_and_user_page.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-content">
            <?php if(session()->has('success')): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="alert alert-success alert-dismissible fade in"
                             style="max-width: 500px; margin: auto">
                            <a href="#" class="close" data-dismiss="alert" style="right: 0"
                               aria-label="close">&times;</a>
                            <strong>Thành công!</strong> <?php echo e(session()->get('success')); ?>

                            <?php
                                session()->forget('success');
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="alert alert-danger alert-dismissible fade in"
                             style="max-width: 500px; margin: auto">
                            <a href="#" class="close" data-dismiss="alert" style="right: 0"
                               aria-label="close">&times;</a>
                            <strong>Thất bại!</strong> <?php echo e(session()->get('error')); ?>

                            <?php
                                session()->forget('error');
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('main'); ?>

        </div>

        <?php echo $__env->make('layout.admin_and_user_page.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</div>


</body>
<!--   Core JS Files  -->
<script src="<?php echo e(asset('admin_asset/js/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('admin_asset/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('admin_asset/js/perfect-scrollbar.jquery.min.js')); ?>" type="text/javascript"></script>


<!--  Forms Validations Plugin -->
<script src="<?php echo e(asset('admin_asset/js/jquery.validate.min.js')); ?>"></script>

<!--  Select Picker Plugin -->
<script src="<?php echo e(asset('admin_asset/js/bootstrap-selectpicker.js')); ?>"></script>

<!--  Checkbox, Radio, Switch and Tags Input Plugins -->
<script src="<?php echo e(asset('admin_asset/js/bootstrap-switch-tags.min.js')); ?>"></script>

<!--  Charts Plugin -->
<script src="<?php echo e(asset('admin_asset/js/chartist.min.js')); ?>"></script>

<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('admin_asset/js/bootstrap-notify.js')); ?>"></script>

<!-- Sweet Alert 2 plugin -->
<script src="<?php echo e(asset('admin_asset/js/sweetalert2.js')); ?>"></script>

<!-- Wizard Plugin    -->
<script src="<?php echo e(asset('admin_asset/js/jquery.bootstrap.wizard.min.js')); ?>"></script>

<!--  bootstrap Table Plugin    -->
<script src="<?php echo e(asset('admin_asset/js/bootstrap-table.js')); ?>"></script>

<!-- Light Bootstrap Dashboard Core javascript and methods -->
<script src="<?php echo e(asset('admin_asset/js/light-bootstrap-dashboard.js?v=1.4.1')); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>



</html>
<?php /**PATH D:\laragon\www\webtruyen\resources\views/layout/admin_and_user_page/master.blade.php ENDPATH**/ ?>