<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            .image_box {
                position: relative;
                width: 100%;
                display: flex;
                justify-content: center;
                height: 313px;
            }

            .image_box .photo_img {
                font-size: 15em;
            }

            .image_box .photo_img::before {
                position: absolute;
                left: 50%;
                transform: translateX(-50%)
            }

            .autobox {
                background-color: #fff;
                width: 100%;
                overflow-y: auto;
                z-index: 5;
                border-bottom-left-radius: 5px;
                border-bottom-right-radius: 5px;
            }

            .autobox li {
                padding: 6px 0 6px 36px;
                cursor: pointer;
                display: none;
            }

            .autobox li:hover {
                color: #FF914D;
            }

            .autobox.active li {
                display: block;
            }

            .editor_level {
                display: none;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('user.stories.edit', $story)); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 style="padding: 24px 24px 0;"><?php echo e($title ?? ''); ?></h3>
                    <hr>
                </div>
                <div class="content">
                    <form action="<?php echo e(route("user.$table.update", $story->id)); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <input type="hidden" name="id" value="<?php echo e($story->id); ?>">
                        <div class="row">
                            <div class="col-md-3" style="padding: 16px">
                                <label for="file_image" style="width: 100%; height: 100%;">
                                    <div class="image_box">
                                        <img src="<?php echo e($story->image_url); ?>" style="width: 100%; object-fit: cover;"
                                             alt="">
                                        <?php if($errors->any()): ?>
                                            <span class="text-danger"
                                                  style="position: absolute; bottom: 12px;"><?php echo e($errors->first('image')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </label>
                                <input type="file" accept="image/*" style="display: none;" id="file_image"
                                       name="image">
                                <input type="hidden" name="image_old" value="<?php echo e($story->image); ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-target="#collapseOne" href="#"
                                                       data-toggle="collapse-hover">
                                                        <div class="form-group">
                                                            <label for="">Thể loại</label>
                                                            <b class="caret"></b>
                                                        </div>
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="collapseOne" class="panel-collapse collapse collapse-hover">
                                                <div class="panel-body">
                                                    <div class="row">
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-sm-2">
                                                                <div class="checkbox">
                                                                    <input class="filter-input"
                                                                           id="categories<?php echo e($category->id); ?>"
                                                                           name="categories[]" type="checkbox"
                                                                           value="<?php echo e($category->id); ?>"
                                                                           <?php if(in_array($category->id,
                                                                                $story->categories->pluck('id')->toArray())): ?>
                                                                               checked
                                                                            <?php endif; ?>
                                                                    >
                                                                    <label for="categories<?php echo e($category->id); ?>"
                                                                           style="padding-left: 24px">
                                                                        <?php echo e($category->name); ?>

                                                                    </label>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($errors->any()): ?>
                                            <span class="text-danger"><?php echo e($errors->first('categories')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="name" class="control-label">Tên</label>
                                            <input type="text" class="form-control" name="name" id="name"
                                                   value="<?php echo e($story->name); ?>">
                                            <?php if($errors->any()): ?>
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label for="status" class="control-label">Tình trạng</label>
                                            <select name="status" id="status" class="form-control filter-input"
                                                    style="margin-left: 6px">
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"
                                                            <?php if((string)$value === $story->status): ?>
                                                                selected
                                                            <?php endif; ?>
                                                    ><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->any()): ?>
                                                <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-md-offset-1">
                                        <div class="form-group">
                                            <label for="level" class="control-label">Phân loại</label>
                                            <select name="level" id="level" class="form-control filter-input"
                                                    style="margin-left: 6px">
                                                <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($value); ?>"
                                                            <?php if((string)$value === $story->level): ?>
                                                                selected
                                                            <?php endif; ?>
                                                    ><?php echo e($name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->any()): ?>
                                                <span class="text-danger"><?php echo e($errors->first('level')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="author" class="control-label">Tác giả</label>
                                            <input type="text" class="form-control" name="author" id="author"
                                                   value="<?php echo e($story->author->name); ?>" autocomplete="off">
                                            <div class="autobox" id="author_list">
                                                <ul>
                                                </ul>
                                            </div>
                                            <?php if($errors->any()): ?>
                                                <span class="text-danger"><?php echo e($errors->first('author')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group editor_level">
                                            <label for="author_2" class="control-label">Người chỉnh sửa</label>
                                            <input type="text" class="form-control" name="author_2" id="author_2"
                                                   value="<?php echo e(optional($story->author_2)->name); ?>" autocomplete="off">
                                            <div class="autobox" id="author_2_list">
                                                <ul>
                                                </ul>
                                            </div>
                                            <?php if($errors->any()): ?>
                                                <span class="text-danger"><?php echo e($errors->first('author_2')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="describe" class="control-label">Mô tả</label>
                                                <textarea class="form-control" name="descriptions" id="describe">
                                    <?php echo e($story->descriptions); ?>

                                    </textarea>
                                                <?php if($errors->any()): ?>
                                                    <span
                                                            class="text-danger"><?php echo e($errors->first('descriptions')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="footer text-center">
                            <button class="btn btn-primary">Sửa</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            const imageBox = document.querySelector('.image_box');
            const image = document.querySelector('#file_image');

            image.onchange = function () {
                imageBox.innerHTML = '<i class="fa fa-photo photo_img"></i>';
                if (this.files[0] !== undefined) {
                    let url = URL.createObjectURL(this.files[0]);
                    let img = `<img src="${url}" style="width:100%; object-fit: cover;">`;
                    imageBox.innerHTML = img;
                }
            }
        </script>
        <script>
            <?php
                $author = json_encode($authorArray);
                echo "let author_list = $author";
            ?>;

            <?php
                $author2 = json_encode($author2Array);
                echo "let author_2_list = $author2";
            ?>;

            const author = document.querySelector('#author')
            const authorBox = document.querySelector('#author_list');
            showAuthorList(author, authorBox, author_list);

            const author2 = document.querySelector('#author_2')
            const author2Box = document.querySelector('#author_2_list');

            showAuthorList(author2, author2Box, author_2_list);

            function showAuthorList(input, box, listAuthor) {
                input.onkeyup = (e) => {
                    let checkData = e.target.value
                    let dataArr = []

                    if (checkData) {
                        dataArr = listAuthor.filter((data) => {
                            return data.toLocaleLowerCase().startsWith(checkData.toLocaleLowerCase())
                        })
                        dataArr = dataArr.map((data) => {
                            return data = '<li>' + data + '</li>'
                        })
                        box.classList.add('active')
                        showSearch(dataArr)
                        let liItem = box.querySelectorAll('li')
                        for (let i = 0; i < liItem.length; i++) {
                            liItem[i].addEventListener("click", function () {
                                input.value = liItem[i].innerHTML
                                box.classList.remove('active')
                            })
                        }
                    } else {
                        box.classList.remove('active')
                    }
                }

                function showSearch(list) {
                    let listData
                    if (!list.length) {
                        listData = '<li>' + input.value + '</li>'
                    } else {
                        listData = list.join('')
                    }
                    box.innerHTML = listData
                }
            }
        </script>

        <script>
            const levelSelect = document.querySelector('#level');
            let editor_level = document.querySelector('.editor_level')
            if (levelSelect.value === '1') {
                editor_level.style.display = 'block';
            } else {
                editor_level.style.display = 'none';
            }
            levelSelect.onchange = function () {
                if (levelSelect.value === '1') {
                    editor_level.style.display = 'block';
                } else {
                    editor_level.style.display = 'none';
                }
            }
        </script>

        <script src="https://cdn.ckeditor.com/ckeditor5/35.2.0/classic/ckeditor.js"></script>
        <script>
            ClassicEditor.create(document.querySelector('#describe'))
                .then(editor => {
                    console.log(editor);
                })
                .catch(error => {
                    console.error(error);
                });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/user/stories/edit.blade.php ENDPATH**/ ?>