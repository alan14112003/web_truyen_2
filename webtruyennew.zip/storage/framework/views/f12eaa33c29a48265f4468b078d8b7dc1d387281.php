<section class="footer">
    <section class="footer__left">
        <div class="logo">
            <img src="<?php echo e(asset('img/page/logo.png')); ?>" alt="">
        </div>
        <div class="footer__left__contacts">
            Liên hệ với chúng tôi thông qua:
            <span class="contacts__face_book">
                            <a href="">
                                <i class="fa-brands fa-facebook"></i>
                            </a>
                        </span>
        </div>
        <div class="copyright">
            Copyright © web truyện
        </div>
    </section>
    <section class="footer__right">
        <ul class="footer__right__links__box">
            <?php $__currentLoopData = categoryList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="footer__right__links__box__item"><a href="<?php echo e(route('show_categories', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <p class="footer__right__content">
            Mọi thông tin và hình ảnh trên website đều được sưu tầm trên Internet. Chúng tôi không sở hữu
            hay chịu
            trách nhiệm bất kỳ thông tin nào trên web này. Nếu làm ảnh hưởng đến cá nhân hay tổ chức nào,
            khi được
            yêu cầu, chúng tôi sẽ xem xét và gỡ bỏ ngay lập tức.
        </p>
    </section>
</section>
<?php /**PATH D:\laragon\www\webtruyen\resources\views/layout/front_page/footer.blade.php ENDPATH**/ ?>