<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            [class^="pe-"] {
                font-size: 30px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.users.black_list')); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="content">
                        <form action="" class="form-inline" id="form-filter">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="gender">Giới tính</label>
                                        <select name="gender" id="gender" class="form-control select-filter">
                                            <option value="">All</option>
                                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>"
                                                        <?php if($genderFilter === (string)$value): ?> selected <?php endif; ?>
                                                ><?php echo e($gender); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="level_id">Cấp bậc</label>
                                        <select name="level_id" id="level_id" class="form-control select-filter">
                                            <option value="">All</option>
                                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($level->id); ?>"
                                                        <?php if($levelFilter === (string)$level->id): ?> selected <?php endif; ?>
                                                ><?php echo e($level->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <a href="<?php echo e(route("admin.$table.black_list")); ?>" class="btn btn-default btn-fill">Reset</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card-body">
                    <div class="bootstrap-table">
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Info</th>
                                    <th>Cấp bậc</th>
                                    <th>Ảnh đại diện</th>
                                    <th>Ngày vào sổ</th>
                                    <th>Xử lý</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e('###'. $user->id); ?></td>
                                        <td>
                                            <div style="display: flex">
                                                <span style="margin-right: 8px"><?php echo e($user->name); ?></span> -
                                                <span style="margin-left: 8px"><?php echo e($user->gender_name); ?></span>
                                            </div>
                                            <div>
                                                <a href="mailto:<?php echo e($user->email); ?>"
                                                   style="margin: 0 10px"><?php echo e($user->email); ?></a>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e($user->level->name); ?>

                                        </td>
                                        <td>
                                            <style>
                                                img:hover {
                                                    transform: scale(1.2);
                                                    transition: all 0.3s ease;
                                                }
                                            </style>
                                            <?php if(isset($user->avatar)): ?>
                                                <a href="<?php echo e($user->avatar_url); ?>" target="_blank">

                                                    <img style="width: 50px; height: 50px; object-fit: cover;"
                                                         src="<?php echo e($user->avatar_url); ?>">
                                                </a>
                                            <?php else: ?>
                                                <img style="width: 50px; object-fit: cover;"
                                                     src="<?php echo e(asset('img/no_face.png')); ?>">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo e($user->deleted_at); ?>

                                        </td>
                                        <td>
                                            <div class="" style="display: flex;">
                                                <form action="<?php echo e(route("admin.$table.restore", $user->id)); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="pe-7s-refresh-2 text-success"
                                                            style="border: none; background: transparent"></button>
                                                </form>
                                                <form action="<?php echo e(route("admin.$table.kill", $user->id)); ?>"
                                                      method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="pe-7s-trash text-danger"
                                                            style="border: none; background: transparent"></button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="fixed-table-pagination">
                            <div class="pull-right pagination">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            const selectFilters = document.querySelectorAll('#form-filter .select-filter')
            const formFilter = document.querySelector('#form-filter')
            selectFilters.forEach((selectFilter) => {
                selectFilter.onchange = () => {
                    formFilter.submit();
                }
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/users/black_list.blade.php ENDPATH**/ ?>