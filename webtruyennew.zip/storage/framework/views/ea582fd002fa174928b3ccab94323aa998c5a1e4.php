<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/own/index.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/own/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('front_asset/css/own/owl.theme.default.min.css')); ?>">
    <?php $__env->stopPush(); ?>
    <!-- slide -->
    <div class="">
        <h3 class="mt-4 mb-0" style="color: #2980b9;">Truyện đề cử</h3>
    </div>
    <div class="owl-carousel owl-theme mt-2">
        <?php $__currentLoopData = $storiesPin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <a href="<?php echo e(route('show_story', $story->slug)); ?>">
                    <img src="<?php echo e($story->image_url); ?>" alt="<?php echo e($story->name); ?>">
                </a>
                <div class="item_view">
                    <p class="item_view_name text-capitalize">
                        <a href="<?php echo e(route('show_story', $story->slug)); ?>">
                            <?php echo e($story->name); ?>

                        </a>
                    </p>
                    <p class="item_view_chapter">
                        <span class="item_view_chapter_number">
                            <a href="<?php echo e(route('show_chapter', [$story->slug, $story->chapter_new_number])); ?>">
                                Chương <?php echo e($story->chapter_new_number); ?>

                            </a>
                        </span>
                        <span class="item_view_chapter_time">
                            <?php
                            \Carbon\Carbon::setLocale('vi')
                            ?>
                            <?php echo e(\Carbon\Carbon::make($story->chapter_new_time)->diffForHumans(\Carbon\Carbon::now())); ?>

                        </span>
                    </p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row">
        <div class="mb-3 col-12 col-md-8">
            <div class="mt-4 mb-1 d-flex justify-content-between">
                <h3 class="fit-width" style="color: #2980b9;"> Truyện mới</h3>
                <a href="<?php echo e(route('advanced_search')); ?>" class="btn btn-outline-warning">
                    <i class="fa-solid fa-filter text-success"></i>
                </a>
            </div>
            <div class="row">
                <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-sm-4 col-6">
                        <?php if (isset($component)) { $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1 = $component; } ?>
<?php $component = App\View\Components\Story::resolve(['story' => $story] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('story'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Story::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1)): ?>
<?php $component = $__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1; ?>
<?php unset($__componentOriginalf240a0ddce51859d23940992271eda60d1b7c7d1); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($stories->links()); ?>

                </div>
            </div>
        </div>
        <div class="col-12 col-md-4">
            <div class="row mt-4">
                <!-- -----------history---------- -->

                <div class="col-12 mb-3">
                    <div class="history">
                        <div class="history_title">
                            Lịch sử đọc truyện
                        </div>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(isset($histories)): ?>
                                <div class="history_list">
                                <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="list_li history_item" id="history_item-<?php echo e($history->story->id); ?>">
                                            <div class="history_img">
                                                <a href="<?php echo e(route('show_story', $history->story->slug)); ?>">
                                                    <img src="<?php echo e($history->story->image_url); ?>" alt="<?php echo e($history->story->name); ?>">
                                                </a>
                                            </div>
                                            <div class="history_info">
                                                <p class="history_info_name text-capitalize">
                                                    <a href="<?php echo e(route('show_story', $history->story->slug)); ?>">
                                                        <?php echo e($history->story->name); ?>

                                                    </a>
                                                </p>
                                                <div class="history_info_chapter d-flex justify-content-between">
                                            <span class="history_info_chapter_number">
                                                <a href="<?php echo e(route('show_chapter', [$history->story->slug, $history->chapter_number])); ?>">
                                                    Đọc tiếp chương <?php echo e($history->chapter_number); ?>

                                                </a>
                                            </span>
                                                    <a class="history_info_chapter_delete histories_close"
                                                       data-story_id="<?php echo e($history->story_id); ?>"
                                                       data-history_item="history_item-<?php echo e($history->story->id); ?>">
                                                        <i class="fa-solid fa-xmark"></i> Xóa
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(isset($histories)): ?>
                                <div class="history_list">
                                <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="list_li history_item" id="history_item-<?php echo e($history->story_id); ?>">
                                            <div class="history_img">
                                                <a href="<?php echo e(route('show_story', $history->story_slug)); ?>">
                                                    <img src="<?php echo e($history->story_image); ?>" alt="<?php echo e($history->story_name); ?>">
                                                </a>
                                            </div>
                                            <div class="history_info">
                                                <p class="history_info_name text-capitalize">
                                                    <a href="<?php echo e(route('show_story', $history->story_slug)); ?>">
                                                        <?php echo e($history->story_name); ?>

                                                    </a>
                                                </p>
                                                <div class="history_info_chapter d-flex justify-content-between">
                                            <span class="history_info_chapter_number">
                                                <a href="<?php echo e(route('show_chapter', [$history->story_slug, $history->chapter_number])); ?>">
                                                    Đọc tiếp Chương <?php echo e($history->chapter_number); ?>

                                                </a>
                                            </span>
                                                    <a class="history_info_chapter_delete histories_close"
                                                       data-history_item="history_item-<?php echo e($history->story_id); ?>"
                                                       data-story_id="<?php echo e($history->story_id); ?>"
                                                    >
                                                        <i class="fa-solid fa-xmark"></i> Xóa
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- --------top truyen---------- -->
                <div class="col-12 mb-3">
                    <div class="rank_top">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active"
                                   id="top-star-tab"
                                   data-toggle="tab"
                                   href="#top-star"
                                   role="tab"
                                   aria-controls="top-star"
                                   aria-selected="true">Top đánh giá</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link"
                                   id="top-month-tab"
                                   data-toggle="tab"
                                   href="#top-month"
                                   role="tab"
                                   aria-controls="top-month"
                                   aria-selected="false">Top tháng</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link"
                                   id="top-week-tab"
                                   data-toggle="tab"
                                   href="#top-week"
                                   role="tab"
                                   aria-controls="top-week"
                                   aria-selected="false">Top tuần</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link"
                                   id="top-day-tab"
                                   data-toggle="tab"
                                   href="#top-day"
                                   role="tab"
                                   aria-controls="top-day"
                                   aria-selected="false">Top ngày</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active"
                                 id="top-star"
                                 role="tabpanel"
                                 aria-labelledby="top-star-tab">
                                <?php $__currentLoopData = $topFiveStars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topStarItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list_li">
                                        <div class="rank_top_number">
                                            <span class="pos<?php echo e(++$key); ?>">0<?php echo e($key); ?></span>
                                        </div>
                                        <div class="rank_top_img">
                                            <a href="<?php echo e(route('show_story', $topStarItem->name)); ?>">
                                                <img src="<?php echo e($topStarItem->image_url); ?>" alt="<?php echo e($topStarItem->name); ?>">
                                            </a>
                                        </div>
                                        <div class="rank_top_info">
                                            <p class="rank_top_info_name text-capitalize">
                                                <a href="<?php echo e(route('show_story', $topStarItem->name)); ?>">
                                                    <?php echo e($topStarItem->name); ?>

                                                </a>
                                            </p>
                                            <div class="rank_top_info_chapter">
                                                    <span class="rank_top_info_chapter_number">
                                                        <a href="#">
                                                            Chương <?php echo e($topStarItem->chapter_new_number); ?>

                                                        </a>
                                                    </span>
                                                <div class="rank_top_info_chapter_views">
                                                    <i class="fa-regular fa-star"></i> <?php echo e($topStarItem->totalStar); ?>/<?php echo e($topStarItem->number_user); ?> người
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="tab-pane fade" id="top-month" role="tabpanel" aria-labelledby="top-month-tab">
                                <?php $__currentLoopData = $topFiveViewMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topViewMonthItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list_li">
                                        <div class="rank_top_number">
                                            <span class="pos<?php echo e(++$key); ?>">0<?php echo e($key); ?></span>
                                        </div>
                                        <div class="rank_top_img">
                                            <a href="<?php echo e(route('show_story', $topViewMonthItem->slug)); ?>">
                                                <img src="<?php echo e($topViewMonthItem->image_url); ?>" alt="<?php echo e($topViewMonthItem->name); ?>">
                                            </a>
                                        </div>
                                        <div class="rank_top_info">
                                            <p class="rank_top_info_name text-capitalize">
                                                <a href="<?php echo e(route('show_story', $topViewMonthItem->slug)); ?>">
                                                    <?php echo e($topViewMonthItem->name); ?>

                                                </a>
                                            </p>
                                            <div class="rank_top_info_chapter">
                                                    <span class="rank_top_info_chapter_number">
                                                        <a href="<?php echo e(route('show_chapter', [$topViewMonthItem->slug, $topViewMonthItem->chapter_new_number])); ?>">
                                                            Chương <?php echo e($topViewMonthItem->chapter_new_number); ?>

                                                        </a>
                                                    </span>
                                                <div class="rank_top_info_chapter_views">
                                                    <i class="fa-regular fa-eye"></i> <?php echo e($topViewMonthItem->view_number); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="tab-pane fade" id="top-week" role="tabpanel" aria-labelledby="top-week-tab">
                                <?php $__currentLoopData = $topFiveViewWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topViewWeekItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list_li">
                                        <div class="rank_top_number">
                                            <span class="pos<?php echo e(++$key); ?>">0<?php echo e($key); ?></span>
                                        </div>
                                        <div class="rank_top_img">
                                            <a href="<?php echo e(route('show_story', $topViewWeekItem->slug)); ?>">
                                                <img src="<?php echo e($topViewWeekItem->image_url); ?>" alt="<?php echo e($topViewWeekItem->name); ?>">
                                            </a>
                                        </div>
                                        <div class="rank_top_info">
                                            <p class="rank_top_info_name text-capitalize">
                                                <a href="<?php echo e(route('show_story', $topViewWeekItem->slug)); ?>">
                                                    <?php echo e($topViewWeekItem->name); ?>

                                                </a>
                                            </p>
                                            <div class="rank_top_info_chapter">
                                                    <span class="rank_top_info_chapter_number">
                                                        <a href="<?php echo e(route('show_chapter', [$topViewWeekItem->slug, $topViewWeekItem->chapter_new_number])); ?>">
                                                            Chương <?php echo e($topViewWeekItem->chapter_new_number); ?>

                                                        </a>
                                                    </span>
                                                <div class="rank_top_info_chapter_views">
                                                    <i class="fa-regular fa-eye"></i> <?php echo e($topViewWeekItem->view_number); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="tab-pane fade" id="top-day" role="tabpanel" aria-labelledby="top-day-tab">
                                <?php $__currentLoopData = $topFiveViewDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topViewDayItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list_li">
                                        <div class="rank_top_number">
                                            <span class="pos<?php echo e(++$key); ?>">0<?php echo e($key); ?></span>
                                        </div>
                                        <div class="rank_top_img">
                                            <a href="<?php echo e(route('show_story', $topViewDayItem->slug)); ?>">
                                                <img src="<?php echo e($topViewDayItem->image_url); ?>" alt="<?php echo e($topViewDayItem->name); ?>">
                                            </a>
                                        </div>
                                        <div class="rank_top_info">
                                            <p class="rank_top_info_name text-capitalize">
                                                <a href="<?php echo e(route('show_story', $topViewDayItem->slug)); ?>">
                                                    <?php echo e($topViewDayItem->name); ?>

                                                </a>
                                            </p>
                                            <div class="rank_top_info_chapter">
                                                    <span class="rank_top_info_chapter_number">
                                                        <a href="<?php echo e(route('show_chapter', [$topViewDayItem->slug, $topViewDayItem->chapter_new_number])); ?>">
                                                            Chương <?php echo e($topViewDayItem->chapter_new_number); ?>

                                                        </a>
                                                    </span>
                                                <div class="rank_top_info_chapter_views">
                                                    <i class="fa-regular fa-eye"></i> <?php echo e($topViewDayItem->view_number); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="<?php echo e(asset('front_asset/js/own/owl.carousel.js')); ?>"></script>
        <script>
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                autoplay: true,
                autoplayTimeout: 1500,
                autoplayHoverPause: true,

                responsive: {
                    0: {
                        items: 2
                    },
                    600: {
                        items: 3
                    },
                    1000: {
                        items: 5
                    }
                }
            })
        </script>
        <script type="text/javascript">
            $(document).ready(function()
            {
                const historiesClose = $('.histories_close')
                historiesClose.each(function(index, historyClose) {
                    historyClose.onclick = (e) => {
                        let idHistoryElement = e.target.dataset.history_item
                        const historyElement = $('#' + idHistoryElement)
                        const story_id = e.target.dataset.story_id
                        submitDestroyHistory(story_id)
                        historyElement.remove()
                    }
                })

                // khi thực hiện kích vào nút Sign in
                function submitDestroyHistory(story_id)
                {
                    let data = {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        'story_id' : story_id,
                    }
                    //Sử dụng hàm $.ajax()
                    $.ajax({
                        type : 'POST', //kiểu post
                        url  : '<?php echo e(route('history.destroy')); ?>', //gửi dữ liệu sang trang submit.php
                        data : data,
                        success :  function(data)
                        {
                            if($.isEmptyObject(data.error)){
                                console.log(data.success);
                            }else{
                                console.log(data.error);
                            }
                        }
                    });
                    return false;
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.front_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/page/index.blade.php ENDPATH**/ ?>