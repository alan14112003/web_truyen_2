<?php $__env->startSection('main'); ?>
    <?php $__env->startPush('css'); ?>
        <style>
            [class^="pe-"] {
                font-size: 30px;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo e(Breadcrumbs::render('admin.chapters.index')); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">

                </div>
                <div class="card-body">
                    <div class="bootstrap-table">
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>chương</th>
                                        <th>Tên chương</th>
                                        <th>Tên truyện</th>
                                        <th>Trạng thái</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($chapter->number); ?></td>
                                            <td><?php echo e($chapter->name); ?></td>
                                            <td><?php echo e($chapter->story); ?></td>
                                            <td><?php echo e($chapter->pin_name); ?></td>

                                            <td class="td-actions text-right">
                                                <div style="display: flex;">
                                                    <a rel="tooltip" data-original-title="Xem"
                                                        href="<?php echo e(route("admin.stories.chapters.show",
                                                                ['id' => $chapter->story_id, 'number' => $chapter->number])); ?>"
                                                        class="btn btn-simple btn-info btn-icon table-action">
                                                        <i class="fa fa-eye"></i>
                                                    </a>
                                                    <form action="<?php echo e(route("admin.stories.chapters.approve",
                                                                ['id' => $chapter->story_id, 'number' => $chapter->number])); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <button rel="tooltip" data-original-title="duyệt"
                                                            class="btn btn-simple btn-success btn-icon
                                                                table-action">
                                                            <i class="fa fa-check"></i>
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route("admin.stories.chapters.un_approve",
                                                                ['id' => $chapter->story_id, 'number' => $chapter->number])); ?>"
                                                          method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <button rel="tooltip" data-original-title="không duyệt"
                                                                class="btn btn-simple btn-warning btn-icon
                                                                    table-action">
                                                            <i class="fa fa-ban"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="fixed-table-pagination">
                            <div class="pull-right pagination">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_and_user_page.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webtruyen\resources\views/admin/chapters/index.blade.php ENDPATH**/ ?>