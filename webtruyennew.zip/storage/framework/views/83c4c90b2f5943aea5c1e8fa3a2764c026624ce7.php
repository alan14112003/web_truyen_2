<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="#">
                        Home
                    </a>
                </li>

                <!--        here you can add more links for the footer                       -->
            </ul>
        </nav>
        <p class="copyright pull-right">
            &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
        </p>
    </div>
</footer>
<?php /**PATH D:\laragon\www\webtruyen\resources\views/layout/admin_and_user_page/footer.blade.php ENDPATH**/ ?>